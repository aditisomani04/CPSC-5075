-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: cssql    Database: mm_5075_04
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `address_id` int NOT NULL,
  `address_line1` varchar(45) NOT NULL,
  `address_line2` varchar(45) DEFAULT NULL,
  `address_zip` varchar(10) NOT NULL,
  `address_state` varchar(2) NOT NULL,
  `owner_id` int NOT NULL,
  `address_city` varchar(45) NOT NULL,
  PRIMARY KEY (`address_id`,`owner_id`),
  KEY `fk_address_owner_idx` (`owner_id`),
  CONSTRAINT `fk_address_owner` FOREIGN KEY (`owner_id`) REFERENCES `owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `booking_id` int NOT NULL,
  `sitter_id` int NOT NULL,
  `owner_id` int NOT NULL,
  `schedule_id` int NOT NULL,
  `transaction_amount` decimal(5,2) DEFAULT NULL,
  `transaction_status` varchar(10) DEFAULT NULL,
  `transaction_timestamp` datetime DEFAULT NULL,
  `booking_hourly_rate` decimal(3,2) NOT NULL,
  PRIMARY KEY (`booking_id`,`owner_id`,`schedule_id`,`sitter_id`),
  KEY `fk_schedule_has_booking_sitter1_idx` (`sitter_id`),
  KEY `fk_schedule_has_booking_owner1_idx` (`owner_id`),
  KEY `fk_booking_schedule1_idx` (`schedule_id`),
  CONSTRAINT `fk_booking_schedule1` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`schedule_id`),
  CONSTRAINT `fk_schedule_has_booking_owner1` FOREIGN KEY (`owner_id`) REFERENCES `owner` (`owner_id`),
  CONSTRAINT `fk_schedule_has_booking_sitter1` FOREIGN KEY (`sitter_id`) REFERENCES `sitter` (`sitter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owner`
--

DROP TABLE IF EXISTS `owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `owner` (
  `owner_id` int NOT NULL,
  `owner_firstname` varchar(45) NOT NULL,
  `owner_lastname` varchar(45) NOT NULL,
  `owner_email` varchar(100) NOT NULL,
  `owner_birthdate` date NOT NULL,
  `owner_phone_num` varchar(12) NOT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owner`
--

LOCK TABLES `owner` WRITE;
/*!40000 ALTER TABLE `owner` DISABLE KEYS */;
/*!40000 ALTER TABLE `owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet`
--

DROP TABLE IF EXISTS `pet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet` (
  `pet_id` int NOT NULL,
  `pet_name` varchar(45) NOT NULL,
  `pet_species` varchar(20) NOT NULL,
  `pet_breed` varchar(20) DEFAULT NULL,
  `pet_age` smallint DEFAULT NULL,
  `pet_weight` smallint DEFAULT NULL,
  `pet_picture` blob,
  `pet_description` varchar(250) DEFAULT NULL,
  `owner_id` int NOT NULL,
  PRIMARY KEY (`pet_id`,`owner_id`),
  KEY `fk_pet_owner1_idx` (`owner_id`),
  CONSTRAINT `fk_pet_owner1` FOREIGN KEY (`owner_id`) REFERENCES `owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet`
--

LOCK TABLES `pet` WRITE;
/*!40000 ALTER TABLE `pet` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_id` int NOT NULL,
  `review_rating` smallint NOT NULL,
  `review_comments` varchar(250) DEFAULT NULL,
  `review_date` datetime NOT NULL,
  `sitter_id` int NOT NULL,
  `owner_id` int NOT NULL,
  PRIMARY KEY (`review_id`,`sitter_id`,`owner_id`),
  KEY `fk_review_sitter1_idx` (`sitter_id`),
  KEY `fk_review_owner1_idx` (`owner_id`),
  CONSTRAINT `fk_review_owner1` FOREIGN KEY (`owner_id`) REFERENCES `owner` (`owner_id`),
  CONSTRAINT `fk_review_sitter1` FOREIGN KEY (`sitter_id`) REFERENCES `sitter` (`sitter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `schedule_id` int NOT NULL,
  `schedule_start_time` datetime NOT NULL,
  `schedule_end_time` datetime NOT NULL,
  `schedule_instructions` varchar(250) DEFAULT NULL,
  `pet_id` int NOT NULL,
  PRIMARY KEY (`schedule_id`,`pet_id`),
  KEY `fk_schedule_pet1_idx` (`pet_id`),
  CONSTRAINT `fk_schedule_pet1` FOREIGN KEY (`pet_id`) REFERENCES `pet` (`pet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitter`
--

DROP TABLE IF EXISTS `sitter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitter` (
  `sitter_id` int NOT NULL,
  `sitter_firstname` varchar(45) NOT NULL,
  `sitter_lastname` varchar(45) NOT NULL,
  `sitter_description` varchar(250) DEFAULT NULL,
  `sitter_phone_num` varchar(12) NOT NULL,
  `sitter_email` varchar(100) NOT NULL,
  PRIMARY KEY (`sitter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitter`
--

LOCK TABLES `sitter` WRITE;
/*!40000 ALTER TABLE `sitter` DISABLE KEYS */;
/*!40000 ALTER TABLE `sitter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-20 10:40:22
